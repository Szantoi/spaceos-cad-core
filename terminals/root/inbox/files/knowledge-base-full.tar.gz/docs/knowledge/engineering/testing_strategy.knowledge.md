---
name: testing-strategy
description: 'Project-wide testing strategy defining test levels, quality assurance standards, and test planning. Use when planning test coverage, reviewing QA processes, or defining test acceptance criteria.'
domain: engineering
last_updated: 2026-02-24
---

# ?? QA / General Testing Strategy Skill

**Summary:** Ez a skill defini�lja a projekt �tfog� tesztel�si strat�gi�j�t, a tesztel�si szinteket �s a min�s�gbiztos�t�si szabv�nyokat.

## ?? Mikor t�ltsd be?

- **Teszt Tervez�s**: Teszt esetek (Test Cases) �r�sakor.
- **QA Review**: Fejleszt�i tesztek ellen�rz�sekor.
- **Hibajelent�s**: Bug report k�sz�t�sekor.
- **Automata Teszt**: E2E vagy Integr�ci�s tesztek �r�sakor.

---

## ??? Tesztel�si Strat�gia (Test Pyramid)

A projekt a tesztel�si piramis elv�t k�veti a gyors visszacsatol�s �rdek�ben.

1. **Unit Tests (L1)**:
   - ?? **F�kusz**: Izol�lt �zleti logika (Domain Entities, Services).
   - ??? **Eszk�z**: xUnit (Backend), Vitest (Frontend).
   - ? **Sebess�g**: Nagyon gyors (<1s).
2. **Integration Tests (L2)**:
   - ?? **F�kusz**: Komponensek egy�ttm�k�d�se (Controller + DB, Hook + Component).
   - ??? **Eszk�z**: WebApplicationFactory (Backend), React Testing Library (Frontend).
   - ? **Sebess�g**: K�zepes.
3. **E2E / System Tests (L3)**:
   - ?? **F�kusz**: Teljes user flow-k (Login -> Create Project).
   - ??? **Eszk�z**: Playwright (ha van), vagy manu�lis teszt.
   - ? **Sebess�g**: Lass�.

### ?? QA Konvenci�k

- **AAA Pattern**: Arrange (El�k�sz�t�s), Act (Cselekv�s), Assert (Ellen�rz�s).
- **Naming**: `[Method]_[Scenario]_[ExpectedResult]` (pl. `Create_InvalidData_ThrowsException`).
- **Bug Report**: Mindig tartalmazzon reprodukci�s l�p�seket �s elv�rt vs. kapott eredm�nyt.

---

## ?? Teszt Mint�k (N-shot Patterns)

### 1. Unit Test Minta (C# / xUnit)

```csharp
public class ProjectTests
{
    [Fact]
    public void Create_WithValidName_ShouldCreateProject()
    {
        // Arrange
        var name = "Test Project";

        // Act
        var project = Project.Create(name);

        // Assert
        project.Should().NotBeNull();
        project.Name.Should().Be(name);
        project.Status.Should().Be(ProjectStatus.Draft);
    }
}
```

### Param�terezett teszt

```csharp
[Theory]
[InlineData("")]
[InlineData("   ")]
[InlineData(null)]
public void Create_WithInvalidName_ShouldThrow(string? invalidName)
{
    var act = () => Project.Create(invalidName!);
    act.Should().Throw<DomainValidationException>();
}
```

### �llapot �tmenet teszt

```csharp
[Fact]
public void Activate_WhenDraft_ShouldChangeStatusToActive()
{
    // Arrange
    var project = Project.Create("Test");

    // Act
    project.Activate();

    // Assert
    project.Status.Should().Be(ProjectStatus.Active);
}

[Fact]
public void Activate_WhenAlreadyActive_ShouldThrowWorkflowException()
{
    // Arrange
    var project = Project.Create("Test");
    project.Activate();

    // Act
    var act = () => project.Activate();

    // Assert
    act.Should().Throw<WorkflowException>();
}
```

---

## ??? Teszt elnevez�si konvenci�

```text
MethodName_WhenCondition_ShouldExpectedResult

P�ld�k:
- Create_WithValidName_ShouldCreateProject
- Activate_WhenDraft_ShouldChangeStatusToActive
- Delete_WhenHasTasks_ShouldThrowException
```

---

## ? Teszt futtat�s

```powershell
# Minden teszt
dotnet test

# Csak egy projekt
dotnet test JoineryTech.Flow.Core.Tests

# Verbose kimenet
dotnet test --logger "console;verbosity=detailed"

# Sz�r�s n�vre
dotnet test --filter "FullyQualifiedName~ProjectTests"
```

---

## ? Teszt checklist

Minden �zleti met�dushoz:

- [ ] **Happy path** - sikeres eset
- [ ] **Validation error** - hib�s input
- [ ] **Edge case** - hat�resetek (null, �res, max �rt�k)
- [ ] **State transitions** - �llapot �tmenetek (ha van)

---

## ?? Gyakori hib�k

| Hiba | Megold�s |
| ------ | ---------- |
| `Test not discovered` | Hi�nyzik `[Fact]` vagy `[Theory]` attrib�tum |
| `FluentAssertions not found` | `dotnet add package FluentAssertions` |
| `Object reference null` | Arrange r�szben nincs inicializ�lva |

---

## ?? Referencia f�jlok

- `JoineryTech.Flow.Core.Tests/Entities/ProjectTests.cs`
- `JoineryTech.Flow.Core.Tests/DomainServices/ProjectWorkflowTests.cs`
