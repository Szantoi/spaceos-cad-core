---
name: frontend-react
description: 'React 18+ and TypeScript development standards, component patterns and best practices. Use when implementing React components, hooks, TanStack Query, or Vite configuration.'
domain: engineering
last_updated: 2026-02-24
---

# ?? Frontend / React & TypeScript Skill

**Summary:** Ez a skill biztos�tja a React 18+ �s TypeScript fejleszt�s�hez sz�ks�ges szabv�nyokat, komponens mint�kat �s best practice-eket a projektben.

## ?? Mikor t�ltsd be?

- **UI Fejleszt�s**: �j komponens, Page, Layout k�sz�t�se.
- **Logika**: Custom Hook �r�sa, State management.
- **API Integr�ci�**: Adatlek�rdez�s (TanStack Query), Form kezel�s.
- **Hibakeres�s**: React renderel�si hib�k, TypeScript t�pusprobl�m�k.

---

## ??? Architekt�ra �s Szab�lyok

A frontend k�d a **Feature-based** vagy **Component-based** strukt�r�t k�veti.

### ?? Projekt Strukt�ra

```text
src/JoineryTech.Flow.Web/src/
+�� api/                # API kliens �s hooks
+�� features/           # �zleti funkci�k (pl. projects, auth)
+�� components/         # Megosztott UI komponensek (Button, Card)
+�� hooks/              # Megosztott logikai hook-ok
L�� assets/             # Statikus f�jlok
```

---

## ?? K�d mint�k

### Funkcion�lis komponens

```typescript
/**
 * ProjectCard Component
 * Displays a single project card.
 */
interface ProjectCardProps {
    project: ProjectResponse;
    onClick?: () => void;
}

export function ProjectCard({ project, onClick }: ProjectCardProps) {
    return (
        <div className="project-card" onClick={onClick}>
            <h3 className="project-title">{project.title}</h3>
            <p className="project-description">{project.description}</p>
            <span className="project-status">{project.status}</span>
        </div>
    );
}
```

### Data fetching (TanStack Query)

```typescript
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ProjectsService, type CreateProjectRequest } from '../generated';

// Query keys for cache management
export const projectKeys = {
    all: ['projects'] as const,
    detail: (id: string) => ['projects', id] as const,
};

// Lista lek�rdez�s
export function useProjects() {
    return useQuery({
        queryKey: projectKeys.all,
        queryFn: () => ProjectsService.getApiProjects(),
    });
}

// Egyedi projekt lek�rdez�s
export function useProject(id: string) {
    return useQuery({
        queryKey: projectKeys.detail(id),
        queryFn: () => ProjectsService.getApiProjects1(id),
        enabled: !!id,
    });
}

// Mutation (l�trehoz�s)
export function useCreateProject() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: (request: CreateProjectRequest) =>
            ProjectsService.postApiProjects(request),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: projectKeys.all });
        },
    });
}
```

### Lista komponens loading/error kezel�ssel

```typescript
import { useProjects } from '../../api/hooks/useProjects';
import { ProjectCard } from './ProjectCard';
import './ProjectList.css';

interface ProjectListProps {
    onSelectProject?: (projectId: string) => void;
}

export function ProjectList({ onSelectProject }: ProjectListProps) {
    const { data: projects, isLoading, error } = useProjects();

    if (isLoading) {
        return (
            <div className="loading-state">
                <div className="loading-spinner"></div>
                <p>Projektek bet�lt�se...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="error-state">
                <h2>Hiba t�rt�nt</h2>
                <p>{(error as Error).message}</p>
            </div>
        );
    }

    if (!projects || projects.length === 0) {
        return (
            <div className="empty-state">
                <h2>Nincsenek projektek</h2>
            </div>
        );
    }

    return (
        <div className="project-grid">
            {projects.map((project) => (
                <ProjectCard
                    key={project.id}
                    project={project}
                    onClick={() => project.id && onSelectProject?.(project.id)}
                />
            ))}
        </div>
    );
}
```

---

## ?? Styling szab�lyok

A projekt **vanilla CSS**-t haszn�l (NEM MUI/Material-UI!).

```css
/* ? J� - CSS oszt�lyok k�l�n f�jlban */
.project-card {
    padding: 16px;
    margin-top: 8px;
    background: var(--color-surface);
    border-radius: 8px;
}

.project-card:hover {
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}
```

```typescript
// ? J� - className haszn�lata
<div className="project-card">

// ? ROSSZ - inline style (ker�lend�)
<div style={{ padding: '16px', marginTop: '8px' }}>
```

### CSS f�jl elnevez�s

- Komponens mell�: `ProjectList.css` (import: `import './ProjectList.css'`)
- Glob�lis: `index.css`, `App.css`

---

## ? Build parancsok

```powershell
# Navig�lj a frontend mapp�ba
cd JoineryTech.Flow.Web

# F�gg�s�gek telep�t�se
npm install

# Fejleszt�i szerver (Vite)
npm run dev

# Production build
npm run build

# Lint ellen�rz�s
npm run lint

# API kliens gener�l�s (backend fut�sa sz�ks�ges!)
npm run generate:api
```

### API gener�l�s workflow

1. Ind�tsd el a backend-et (`dotnet run` az Api mapp�ban)
2. Futtasd: `npm run generate:api`
3. �jragener�l�dik az `src/api/generated/` mappa

---

## ?? Gyakori hib�k

| Hiba | Megold�s |
| ------ | ---------- |
| `TS2307: Cannot find module` | Hi�nyz� import vagy rossz path |
| `TS2339: Property does not exist` | T�pus defin�ci� hi�nyzik, gener�ld �jra az API-t |
| `useQuery outside Provider` | `QueryClientProvider` kell a `main.tsx`-be |
| `CORS error` | Vite proxy m�k�dik, ellen�rizd a `vite.config.ts`-t |
| `Network Error` | Backend nem fut, ind�tsd el: `dotnet run` |
| `Swagger not found (generate:api)` | Backend fut? URL helyes? (`localhost:5058`) |

---

## ?? API integr�ci�

### Vite proxy konfigur�ci�

```typescript
// vite.config.ts
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:5058',
        changeOrigin: true,
      }
    }
  }
})
```

### OpenAPI kliens haszn�lata

```typescript
// Import a gener�lt service-b�l
import { ProjectsService, WorkTasksService } from '../api/generated';

// K�zvetlen haszn�lat (ritk�n)
const projects = await ProjectsService.getApiProjects();

// ? AJ�NLOTT: Hook-on kereszt�l
const { data, isLoading } = useProjects();
```

---

## ?? Referencia f�jlok

- `src/features/projects/ProjectList.tsx` - Lista komponens minta
- `src/features/projects/ProjectDetails.tsx` - R�szletek komponens minta
- `src/api/hooks/useProjects.ts` - Query hook minta
- `src/api/hooks/useWorkTasks.ts` - Nested query minta
- `vite.config.ts` - Proxy konfigur�ci�
