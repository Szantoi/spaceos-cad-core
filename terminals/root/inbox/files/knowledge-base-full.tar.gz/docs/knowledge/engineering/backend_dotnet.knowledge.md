---
name: backend-dotnet
description: '.NET 10 Web API development standards, code patterns and best practices following Clean Architecture. Use when implementing controllers, DTOs, services, or domain logic in C#.'
domain: engineering
last_updated: 2026-02-24
---

# ??? Backend / .NET Core Development Skill

**Summary:** Ez a skill biztos�tja a .NET 10 Web API fejleszt�s�hez sz�ks�ges szabv�nyokat, k�dmint�kat �s best practice-eket a Clean Architecture elvei alapj�n.

## ?? Mikor t�ltsd be?

- **API Fejleszt�s**: Controller, Endpoint, Middleware l�trehoz�sa.
- **�zleti Logika**: Domain Service, Validation, DTO mapping.
- **Hibakeres�s**: Backend build hib�k vagy runtime exception-�k eset�n.

---

## ??? Architekt�ra �s Szab�lyok (Clean Architecture)

A projekt szigor� r�tegz�d�st k�vet. A f�gg�s�gek csak **befel�** mutathatnak.

1. **Core (Domain)**:
   - ? Nem f�gghet semmit�l (sem DB, sem HTTP).
   - ? Tartalmazza: Entit�sok, Value Objects, Domain Services, Repository Interface-ek, Custom Exceptions.
2. **Infra (Infrastructure)**:
   - ? F�gg a Core-t�l.
   - ? Tartalmazza: EF Core DbContext, Repository Implement�ci�k, External Services (Email, File).
3. **Api (Presentation)**:
   - ? F�gg a Core-t�l �s az Infra-t�l.
   - ? Tartalmazza: Controllers, DTOs, Middleware, DI Configuration (`Program.cs`).

### ?? K�dol�si Konvenci�k

- **Rich Domain Model**: Az entit�sok nem csak adatot t�rolnak, hanem viselked�st is (met�dusok).
- **Private Setters**: `public string Title { get; private set; }` - csak met�duson vagy konstruktoron kereszt�l m�dos�that�.
- **DTO-k haszn�lata**: Soha ne adj vissza Entit�st a Controllerb�l. Mindig map-eld DTO-ra.
- **Async/Await**: Minden I/O m�velet legyen aszinkron (`Task`, `await`).

---

## ?? K�d Mint�k (N-shot Patterns)

### 1. Controller Minta

```csharp
[ApiController]
[Route("api/[controller]")]
public class ProjectsController : ControllerBase
{
    private readonly IProjectRepository _repository;

    public ProjectsController(IProjectRepository repository)
    {
        _repository = repository;
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProjectDto>> GetById(Guid id)
    {
        var project = await _repository.GetByIdAsync(id);
        if (project == null) return NotFound();

        return Ok(project.ToDto()); // Vagy AutoMapper
    }

    [HttpPost]
    public async Task<ActionResult<Guid>> Create(CreateProjectDto dto)
    {
        // 1. Valid�ci� (ha nincs FluentValidation)
        if (string.IsNullOrEmpty(dto.Title)) return BadRequest("Title is required");

        // 2. Domain Logic
        var project = Project.Create(dto.Title, dto.Description);

        // 3. Persistence
        await _repository.AddAsync(project);

        return CreatedAtAction(nameof(GetById), new { id = project.Id }, project.Id);
    }
}
```

### 2. DTO (Data Transfer Object) Minta

```csharp
// Request DTO (Input)
public record CreateProjectDto(string Title, string? Description);

// Response DTO (Output)
public record ProjectDto(Guid Id, string Title, string Status, DateTime CreatedAt);
```

### 3. Domain Entity Minta (Rich Model)

```csharp
public class Project : Entity
{
    public string Title { get; private set; }
    public ProjectStatus Status { get; private set; }

    // Factory method (Constructor helyett)
    public static Project Create(string title, string? description)
    {
        if (string.IsNullOrWhiteSpace(title))
            throw new DomainException("Title cannot be empty");

        return new Project
        {
            Id = Guid.NewGuid(),
            Title = title,
            Status = ProjectStatus.Draft,
            CreatedAt = DateTime.UtcNow
        };
    }

    // Domain behavior
    public void Start()
    {
        if (Status != ProjectStatus.Draft)
            throw new DomainException("Only draft projects can be started");

        Status = ProjectStatus.Active;
    }
}
```

## Build / Run parancsok

- `dotnet test JoineryTech.Flow.Core.Tests`
- `dotnet ef migrations add AddProject -p JoineryTech.Flow.Infra -s JoineryTech.Flow.Api`

## Gyakori hib�k

- Nem fut a migration: ellen�rizd a startup DbContext regisztr�ci�j�t.

## Referenci�k

- `JoineryTech.Flow.Core/Entities/Project.cs`
- `JoineryTech.Flow.Infra/Persistence`
