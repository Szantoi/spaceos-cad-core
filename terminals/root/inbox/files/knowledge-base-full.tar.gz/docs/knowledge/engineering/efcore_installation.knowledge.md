---
name: efcore-installation
description: 'Entity Framework Core environment setup guide: NuGet packages and dotnet-ef tool installation. Use when setting up EF Core for the first time or troubleshooting tool installations.'
domain: engineering
last_updated: 2026-02-24
---

# ??? EF Core Telep�t�s �s Setup Skill

**Summary:** Gyors �tmutat� az Entity Framework Core k�rnyezet be�ll�t�s�hoz, a sz�ks�ges NuGet csomagokhoz �s a `dotnet-ef` eszk�z telep�t�s�hez.

## ?? Mikor t�ltsd be?

- **Projekt Setup**: �j projekt ind�t�sakor az adatb�zis r�teg el�k�sz�t�s�hez.
- **K�rnyezet Hiba**: Ha a `dotnet ef` parancs nem tal�lhat� vagy verzi�hiba van.
- **CI/CD**: Pipeline konfigur�l�sakor.

---

## ?? 1. Sz�ks�ges NuGet Csomagok

Ezeket a parancsokat a megfelel� projekt mapp�j�ban futtasd.

### Infra Projekt (`JoineryTech.Flow.Infra`)

```powershell
dotnet add package Microsoft.EntityFrameworkCore
dotnet add package Microsoft.EntityFrameworkCore.Sqlite
dotnet add package Microsoft.EntityFrameworkCore.Design
```

- `dotnet-ef` telep�t�se (helyi, aj�nlott repo szinten):

```powershell
# ha nincs tool manifest
dotnet new tool-manifest --force
# add a local tool dependency
# Friss�tsd a dotnet-tools.json-be: "dotnet-ef": { "version": "10.0.2", "commands": ["dotnet-ef"] }
# majd restore
dotnet tool restore --verbosity diagnostic
```

- Ha glob�lisan szeretn�d (gyors megold�s, admin lehet kell):

```powershell
dotnet tool install --global dotnet-ef --version 10.0.2
# ellen�rz�s
& "$env:USERPROFILE\\.dotnet\\tools\\dotnet-ef.exe" --version
```

- Migr�ci� l�trehoz�sa �s alkalmaz�sa (p�lda a repo-ra):

```powershell
# migr�ci� l�trehoz�sa
dotnet ef migrations add InitialCreate -p JoineryTech.Flow.Infra -s JoineryTech.Flow.Api
# migr�ci� alkalmaz�sa (adatb�zis l�trehoz�sa)
dotnet ef database update -p JoineryTech.Flow.Infra -s JoineryTech.Flow.Api
```

> Tipp: ha `dotnet ef` a repo rootb�l futtatva a helyi toolt prefer�lja, �s te glob�lis eszk�zt haszn�lsz, h�vd meg a glob�lis futtathat�t k�zvetlen�l (`& "$env:USERPROFILE\\.dotnet\\tools\\dotnet-ef.exe" <cmd>`).

---

## Program.cs: automatikus migr�ci� futtat�s indul�skor (opcion�lis)

- P�lda k�d:

```csharp
using var scope = app.Services.CreateScope();
var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
db.Database.Migrate();
```

---

## Hibakeres�s / gyakori probl�m�k

- H�l�zati timeout / TLS reset (NU1301, HTTP timeouts):
  - Pr�b�ld meg egy m�sik h�l�zatr�l (mobil hotspot) � gyakran corporate proxy/DPI okozza.
  - `dotnet nuget locals all --clear` majd `dotnet restore --verbosity diagnostic` a hiba pontos logj�nak gy�jt�s�hez.
  - Ha a h�l�zat nem megb�zhat�, haszn�lj helyi forr�st: t�ltsd le a `.nupkg` f�jlokat megb�zhat� h�l�zatr�l �s add a `dotnet nuget add source "C:\nuget-local" -n LocalPackages`-t.

- PowerShell `Invoke-WebRequest` vs nat�v `curl`:
  - A PowerShell HTTP kliens bizonyos k�rnyezetekben timeoutolhat m�sk�pp; nat�v `curl.exe` gyakran megb�zhat�bb diagnosztik�hoz.

- `dotnet tool restore` megszakad/exit code 1:
  - Ellen�rizd `dotnet-tools.json` szintaxis�t (verzi� pontos megad�sa, ne haszn�lj `8.*` jel�l�st), majd `dotnet tool restore --verbosity diagnostic`.
  - Ha nem megy, glob�lis telep�t�s vagy CI alap� gener�l�s lehets�ges alternat�va.

- Design-time factory vagy `Microsoft.EntityFrameworkCore.Design` hi�nya:
  - Ha a migr�ci� fut�s k�zben a `DbContext` p�ld�nyos�t�sa sikertelen a design-time k�rnyezetben, gy�z�dj meg hogy a `Microsoft.EntityFrameworkCore.Design` csomag telep�tve van a startup (vagy Infra) projektre.

---

## Alternat�v/backup megold�sok

- CI gener�l�s (GitHub Actions): k�sz�ts egy workflow-ot, ami restore-olja a megold�st egy megb�zhat� runneren, l�trehozza a migr�ci�t �s commitolja (�s push-olja) a migr�ci�s f�jlokat. Ez j�l j�n, ha helyi h�l�zati korl�tok vannak.
- Lok�lis `.nupkg` feed (offline vagy korpor�t k�rnyezetben megb�zhat� megold�s).

---

## Verifik�ci� (DoD)

- `dotnet ef --version` el�rhet� �s a k�v�nt verzi�t adja vissza.
- `dotnet ef migrations add InitialCreate` l�trehozza a migr�ci�s f�jlokat a `Migrations/` mapp�ban.
- `dotnet ef database update` l�trehozza az SQLite f�jlt (pl. `JoineryTech.Flow.Api/flow.db`) �s a t�bl�k megvannak.
- API indul, a Swagger UI el�rhet� �s adatok perziszt�lnak �jraind�t�s ut�n.

---

## Hivatkoz�sok a repo-ra

- P�ld�k a projektben: `JoineryTech.Flow.Infra/AppDbContext.cs`, `JoineryTech.Flow.Infra/Migrations/`, `JoineryTech.Flow.Api/appsettings.json` (ConnectionStrings)
- CI p�lda is hozz�adva: `.github/workflows/generate-migration.yml`

---

Ha szeretn�d, beillesztem ezt a skillt `src/agent-system/database/roles/skills/index.md`-be vagy l�trehozok egy r�vid checklist f�jlt, amelyet fejleszt�k k�nnyen k�vethetnek. Szeretn�d, hogy linkeljem be az �j skillt az `skills` indexbe is? ??
