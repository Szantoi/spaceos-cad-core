---
name: database-efcore
description: 'Database layer (Infra) implementation standards with EF Core configurations and Repository patterns. Use when working with entity configurations, Fluent API, SQLite, or repository implementations.'
domain: engineering
last_updated: 2026-02-24
---

# ??? Backend / Database & EF Core Skill

**Summary:** Ez a skill biztos�tja az adatb�zis r�teg (Infra) implement�l�s�hoz sz�ks�ges szabv�nyokat, EF Core konfigur�ci�kat �s Repository mint�kat.

## ?? Mikor t�ltsd be?

- **Adatb�zis Tervez�s**: Entit�sok konfigur�l�sa (Fluent API), DbContext be�ll�t�sa.
- **Adatkezel�s**: Repository implement�ci� �r�sa (CRUD).
- **Migr�ci�**: Adatb�zis s�ma m�dos�t�sa.
- **Seed Data**: Kezdeti adatok felt�lt�se.

---

## ??? Architekt�ra �s Szab�lyok

A perzisztencia r�teg a **Clean Architecture** `Infrastructure` r�teg�ben helyezkedik el.

1. **Core (Domain)**:
   - ? Tartalmazza az `IProjectRepository` interf�szt.
   - ? Nem tud az EF Core-r�l (nincs `DbSet`, nincs `DbContext`).
2. **Infra (Persistence)**:
   - ? Implement�lja az interf�szeket (`ProjectRepository`).
   - ? Tartalmazza a `DbContext`-et �s a Migr�ci�kat.
   - ? Haszn�lja a `Microsoft.EntityFrameworkCore` csomagokat.

### ?? K�dol�si Konvenci�k

- **Fluent API**: Az entit�sok konfigur�l�s�t k�l�n `IEntityTypeConfiguration<T>` oszt�lyokban v�gezz�k, nem az `OnModelCreating`-ben �mlesztve.
- **Scoped Lifetime**: A `DbContext` �s a Repository-k `Scoped` �lettartam�ak.
- **No Logic in Repo**: A Repository csak adatot mozgat, �zleti logik�t nem tartalmaz.
- **Async**: Minden adatb�zis m�velet aszinkron (`ToListAsync`, `SaveChangesAsync`).

---

## ?? K�d Mint�k (N-shot Patterns)

### 1. Entity Configuration Minta (Fluent API)

```csharp
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using JoineryTech.Flow.Core.Entities;

namespace JoineryTech.Flow.Infra.Persistence.Configurations;

public class ProjectConfiguration : IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        // Primary Key
        builder.HasKey(p => p.Id);

        // Properties
        builder.Property(p => p.Title)
            .IsRequired()
            .HasMaxLength(Project.MaxTitleLength);

        builder.Property(p => p.Status)
            .HasConversion<string>()  // Enum t�rol�sa stringk�nt
            .IsRequired();

        // Relationships
        builder.HasMany<WorkTask>()
            .WithOne()
            .HasForeignKey(t => t.ProjectId)
            .OnDelete(DeleteBehavior.Cascade);

        // Indexes
        builder.HasIndex(p => p.Title)
            .IsUnique();

        // Private setters support (ha sz�ks�ges)
        // builder.Property(p => p.Title).HasField("_title");
    }
}
```

### Entity Configuration (Fluent API)

```csharp
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using JoineryTech.Flow.Core.Entities;

namespace JoineryTech.Flow.Infra.Persistence.Configurations;

public class ProjectConfiguration : IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Title)
            .IsRequired()
            .HasMaxLength(Project.MaxTitleLength);

        builder.Property(p => p.Description)
            .HasMaxLength(500);

        builder.Property(p => p.Status)
            .HasConversion<string>()  // Enum -> string
            .IsRequired();

        builder.HasMany<WorkTask>()
            .WithOne()
            .HasForeignKey(t => t.ProjectId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasIndex(p => p.Title)
            .IsUnique();
    }
}
```

### Repository implement�ci� (EF Core)

```csharp
using Microsoft.EntityFrameworkCore;
using JoineryTech.Flow.Core.Entities;
using JoineryTech.Flow.Core.Interfaces;

namespace JoineryTech.Flow.Infra.Persistence;

public class ProjectRepository : IProjectRepository
{
    private readonly AppDbContext _context;

    public ProjectRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<Project?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await _context.Projects
            .FirstOrDefaultAsync(p => p.Id == id, cancellationToken);
    }

    public async Task<List<Project>> ListAsync(CancellationToken cancellationToken = default)
    {
        return await _context.Projects
            .OrderByDescending(p => p.CreatedAt)
            .ToListAsync(cancellationToken);
    }

    public async Task AddAsync(Project project, CancellationToken cancellationToken = default)
    {
        _context.Projects.Add(project);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateAsync(Project project, CancellationToken cancellationToken = default)
    {
        _context.Projects.Update(project);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task<bool> IsTitleUniqueAsync(string title, Guid? excludeId = null, CancellationToken cancellationToken = default)
    {
        return !await _context.Projects
            .AnyAsync(p =>
                p.Title == title &&
                (!excludeId.HasValue || p.Id != excludeId.Value),
                cancellationToken);
    }
}
```

### DI Registration (Program.cs)

```csharp
// SQLite connection string
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? "Data Source=joinerytech.db";

// Register DbContext
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlite(connectionString));

// Register repositories (Scoped for EF Core!)
builder.Services.AddScoped<IProjectRepository, ProjectRepository>();
builder.Services.AddScoped<IWorkTaskRepository, WorkTaskRepository>();
```

**?? FONTOS**: InMemory-n�l `AddSingleton`, EF Core-n�l `AddScoped`!

### WorkTaskRepository minta

```csharp
using Microsoft.EntityFrameworkCore;
using JoineryTech.Flow.Core.Entities;
using JoineryTech.Flow.Core.Interfaces;

namespace JoineryTech.Flow.Infra.Persistence;

public class WorkTaskRepository : IWorkTaskRepository
{
    private readonly AppDbContext _context;

    public WorkTaskRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task AddAsync(WorkTask task)
    {
        _context.WorkTasks.Add(task);
        await _context.SaveChangesAsync();
    }

    public async Task<WorkTask?> GetByIdAsync(Guid id)
    {
        return await _context.WorkTasks
            .FirstOrDefaultAsync(t => t.Id == id);
    }

    public async Task<IEnumerable<WorkTask>> ListByProjectAsync(Guid projectId)
    {
        return await _context.WorkTasks
            .Where(t => t.ProjectId == projectId)
            .OrderByDescending(t => t.CreatedAt)
            .ToListAsync();
    }

    public async Task UpdateAsync(WorkTask task)
    {
        _context.WorkTasks.Update(task);
        await _context.SaveChangesAsync();
    }
}
```

### appsettings.json

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=joinerytech.db"
  }
}
```

---

## ? Migr�ci� parancsok

```powershell
# FONTOS: Mindig az Api mapp�b�l futtasd (startup project)
cd JoineryTech.Flow.Api

# �j migr�ci� l�trehoz�sa
dotnet ef migrations add InitialCreate --project ../JoineryTech.Flow.Infra

# Migr�ci� alkalmaz�sa (DB friss�t�s)
dotnet ef database update --project ../JoineryTech.Flow.Infra

# Migr�ci� visszavon�sa
dotnet ef migrations remove --project ../JoineryTech.Flow.Infra

# DB t�rl�se �s �jra�p�t�se
dotnet ef database drop --project ../JoineryTech.Flow.Infra
dotnet ef database update --project ../JoineryTech.Flow.Infra
```

---

## ?? Seed Data

### Option 1: HasData (migr�ci�ba �p�l)

```csharp
// ProjectConfiguration.cs
public void Configure(EntityTypeBuilder<Project> builder)
{
    // ... egy�b konfig ...

    builder.HasData(
        new { Id = Guid.Parse("..."), Title = "Demo Project", ... }
    );
}
```

### Option 2: Runtime seeding (aj�nlott)

```csharp
// Program.cs (app.Run() el�tt)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.MigrateAsync();

    if (!await db.Projects.AnyAsync())
    {
        db.Projects.AddRange(
            Project.Create("Konyhab�tor - Kov�cs csal�d", "Egyedi konyhab�tor"),
            Project.Create("H�l�szoba gardr�b", "Be�p�tett szekr�ny")
        );
        await db.SaveChangesAsync();
    }
}
```

---

## ?? Gyakori hib�k

| Hiba | Megold�s |
| ------ | ---------- |
| `No database provider configured` | Hi�nyzik `UseSqlite()` a Program.cs-b�l |
| `Unable to create DbContext` | Hi�nyzik `Microsoft.EntityFrameworkCore.Design` package |
| `The entity type requires a primary key` | Hi�nyzik `HasKey()` vagy `[Key]` attrib�tum |
| `Cannot insert duplicate key` | Unique constraint violation - ellen�rizd az adatot |
| `Private setter not working` | Haszn�lj `builder.Property().HasField()` vagy backing field-et |
| `Navigation property null` | Hi�nyzik `.Include()` a query-b�l |
| `Enum stored as int` | Haszn�lj `.HasConversion<string>()` |

### Private setter kezel�se EF Core-ral

```csharp
// Ha az entit�snak private setter-ei vannak:
builder.Property(p => p.Title)
    .HasField("_title");  // backing field haszn�lata

// VAGY ConfigureConventions-ban:
protected override void ConfigureConventions(ModelConfigurationBuilder builder)
{
    builder.Properties<string>()
        .HaveMaxLength(200);
}
```

---

## ?? InMemory � SQLite migr�ci� l�p�sei

1. **NuGet packages hozz�ad�sa** (l�sd fent)
2. **AppDbContext l�trehoz�sa** (`Infra/Persistence/AppDbContext.cs`)
3. **Entity Configuration** (`Infra/Persistence/Configurations/*.cs`)
4. **Repository �t�r�sa** (InMemory � EF Core)
5. **DI registration** (Program.cs)
6. **Migr�ci� gener�l�sa** (`dotnet ef migrations add`)
7. **Seed data** (runtime seeding aj�nlott)
8. **InMemory repository t�rl�se** (ha m�r nem kell)

---

## ?? Referencia f�jlok

- `JoineryTech.Flow.Core/Interfaces/IProjectRepository.cs` - Interface minta
- `JoineryTech.Flow.Infra/Persistence/InMemoryProjectRepository.cs` - Jelenlegi implement�ci�
- `JoineryTech.Flow.Api/Program.cs` - DI konfigur�ci�
